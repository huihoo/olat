/*
 *  wasy10/def.js
 *  
 *  This file loads the  font into jsMath. To do this use
 *  
 *      <SCRIPT>jsMath.Font.Load("wasy10")</SCRIPT>
 *
 *  after loading jsMath.js itself.  The user will need to have
 *  the wasy10.ttf font installed, otherwise corresponding unicode
 *  characters will be used, but the mapping is not perfect, and it is not 
 *  customized on a per-browser basis as it probably should be.
 *  
 *  If the font isn't installed, the user will receive a message indicating
 *  that fact, and pointing to the jsMath web site where the font can be
 *  downloaded.
 *  
 *  Once this file is loaded, you can use \char{wasy10}{nn} to access
 *  any character in the font.  In addition, the \wasy10 macro will switch to
 *  the eufm font
 *  
 *  ---------------------------------------------------------------------
 *
 *  jsMath is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  jsMath is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with jsMath; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

jsMath.Add(jsMath.TeX,{

  wasy10: [
    // 00 - 0F
    [0.667,0.688],
    [0.778,0.53,0.0383],
    [0.778,0.626,0.137],
    [0.778,0.53,0.0383],
    [0.778,0.626,0.137],
    [0.667,0.438],
    [0.737,0.553],
    [1.04,0.688],
    [0.736,0.688],
    [0.5,0.649],
    [0.481,0.475,0,{ic: 0.0278}],
    [0.556,0.688],
    [0.333,0.688],
    [0.333,0.688],
    [0.389,0.194,0.0278],
    [0.722,0.688],
    // 10 - 1F
    [0.778,0.53,0.0383],
    [0.778,0.53,0.0383],
    [0.444,0.688,0.0938],
    [0.833,0.649,0.153],
    [0.833,0.649,0.153],
    [0.781,0.586,0.0831],
    [0.778,0.586,0.0831],
    [0.806,0.688],
    [0.667,0.438],
    [0.542,0.53,0.194],
    [0.799,0.705],
    [0.737,0.553],
    [0.806,0.649],
    [0.778,0.438],
    [0.778,0.626,0.137],
    [0.781,0.586,0.0831],
    // 20 - 2F
    [0.778,0.586,0.0831],
    [1,0.688,0.194],
    [1,0.688,0.194],
    [0.778,0.586,0.0831],
    [0.778,0.586,0.0831],
    [0.778,0.586,0.0831],
    [0.542,0.741],
    [0.542,0.753,0.194],
    [0.333,0.367,-0.133],
    [0.333,0.367,-0.133],
    [0.5,0.688,0.194],
    [0.5,0.688,0.194],
    [0.806,0.649],
    [0.806,0.649],
    [0.806,0.688],
    [0.806,0.649],
    // 30 - 3F
    [0.722,0.688],
    [0.722,0.438,-0.0556],
    [0.747,0.506,0.01],
    [0.792,0.586,0.0938],
    [0.747,0.506,0.01],
    [0.747,0.506,0.01],
    [0.747,0.506,0.01],
    [0.719,0.506,0.01],
    [1,0.688,0.194],
    [0.636,0.553,0.0535],
    [0.667,0.367,-0.133],
    [1,0.367,-0.133],
    [0.778,0.53,0.0383],
    [0.778,0.53,0.0383],
    [0.778,0.649,0.153],
    [0.778,0.649,0.153],
    // 40 - 4F
    [0.778,0.506,0.01],
    [0.774,0.53,0.0383],
    [0.686,0.586,0.0831],
    [0.686,0.586,0.0831],
    [0.778,0.586,0.0831],
    [0.778,0.586,0.0831],
    [0.667,0.688],
    [0.778,0.586,0.0831],
    [0.778,0.586,0.0831],
    [0.778,0.586,0.0831],
    [0.778,0.586,0.0831],
    [0.578,0.553,0.0535],
    [0.578,0.553,0.0535],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    // 50 - 5F
    [0.333,0.553,0.0535],
    [0.333,0.553,0.0535],
    [0.333,0.553,0.0535],
    [0,0,0],
    [0,0,0],
    [0.444,0.438],
    [0.799,0.705],
    [0.972,0.85,0.0938],
    [0.701,0.688],
    [0.583,0.688,0.194],
    [0.542,0.626,0.116],
    [0.653,0.688,0.181],
    [0.583,0.688],
    [0.806,0.688],
    [0.806,0.688],
    [1.01,0.688],
    // 60 - 6F
    [1.15,0.688,0.194],
    [1.15,0.53],
    [1.15,0.688,0.194],
    [0.705,0.705],
    [0.806,0.688],
    [1.15,0.438],
    [0.806,0.688],
    [0.5,0.688,0.194],
    [1,0.741,0.0535],
    [0.556,0.688,0.194],
    [0.681,0.688],
    [0.5,0.688],
    [0.472,0.438],
    [0.55,0.741],
    [0.778,0.649,0.137],
    [0.778,0.649,0.137],
    // 70 - 7F
    [0.778,0.649,0.137],
    [0.778,0.649,0.137],
    [0.417,0,1.11,{ic: 0.194, n: 119}],
    [0.75,0,1.11,{ic: 0.194, n: 120}],
    [1.08,0,1.11,{ic: 0.194, n: 121}],
    [0.722,0,1.11,{n: 122}],
    [0.75,0,1.11,{ic: 0.194, n: 123}],
    [0.556,0,1.67,{ic: 0.222}],
    [1.06,0,1.67,{ic: 0.222}],
    [1.56,0,1.67,{ic: 0.222}],
    [0.556,0,1.67,{ic: 0.222}],
    [1.06,0,1.67,{ic: 0.222}],
    [0.111,0.688],
    [0.778,0.649,0.137],
    [0.778,0.649,0.137],
    [0.5,0.506]
  ]

});
jsMath.Setup.EncodeFont('wasy10');

jsMath.Font.Register({
  name: 'wasy10',
  prefix: 'jsMath-',
  // The test used to see if font is available
  test: jsMath.Font.Test1, testChar: 0x74, testFactor: 2,
  // Can add style, styles, macros here
  tex: function (font,fam) {
    // do browser-specific adjustments here
  },
  fallback: function (font,fam) {
    // set up unicode font here, e.g.
    //    jsMath.Update.TeXfonts({
    //      wasy10: {
    //         '0': {c: '&#x221B;'},  // use code point U221B for character 0
    //        '10': {c: '&#x210C;'}   // use code point U210C for character 10
    //      }
    //    });
  }
});
