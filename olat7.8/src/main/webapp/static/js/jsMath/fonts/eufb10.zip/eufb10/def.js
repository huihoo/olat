/*
 *  eufb10/def.js
 *  
 *  This file loads the  font into jsMath. To do this use
 *  
 *      <SCRIPT>jsMath.Font.Load("eufb10")</SCRIPT>
 *
 *  after loading jsMath.js itself.  The user will need to have
 *  the eufb10.ttf font installed, otherwise corresponding unicode
 *  characters will be used, but the mapping is not perfect, and it is not 
 *  customized on a per-browser basis as it probably should be.
 *  
 *  If the font isn't installed, the user will receive a message indicating
 *  that fact, and pointing to the jsMath web site where the font can be
 *  downloaded.
 *  
 *  Once this file is loaded, you can use \char{eufb10}{nn} to access
 *  any character in the font.  In addition, the \eufb10 macro will switch to
 *  the eufm font
 *  
 *  ---------------------------------------------------------------------
 *
 *  jsMath is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  jsMath is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with jsMath; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

jsMath.Add(jsMath.TeX,{

  eufb10: [
    // 00 - 0F
    [0,0,0],
    [0.587,0.629],
    [0.394,0.691,0.189],
    [0.387,0.629],
    [0.593,0.691,0.189],
    [0.393,0.691],
    [0.398,0.691],
    [0,0,0],
    [0.981,0.691],
    [0.727,0.475],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    // 10 - 1F
    [0,0,0],
    [0,0,0],
    [0.254,0.691],
    [0.254,0.691],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    // 20 - 2F
    [0,0,0],
    [0.349,0.691],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0.871,0.691],
    [0.25,0.691],
    [0.459,0.749,0.25],
    [0.459,0.749,0.25],
    [0.328,0.629],
    [0.893,0.583,0.0832],
    [0.328,0.108],
    [0.893,0.583,0.0832],
    [0.328,0.108],
    [0.593,0.749,0.25],
    // 30 - 3F
    [0.593,0.475],
    [0.593,0.475],
    [0.593,0.475],
    [0.593,0.475,0.189],
    [0.593,0.475,0.189],
    [0.593,0.475,0.189],
    [0.593,0.691],
    [0.593,0.475,0.189],
    [0.593,0.691],
    [0.593,0.475,0.189],
    [0.255,0.475],
    [0.255,0.475,0.126],
    [0,0,0],
    [0.582,0.475],
    [0,0,0],
    [0.428,0.691],
    // 40 - 4F
    [0,0,0],
    [0.847,0.691],
    [1.04,0.691],
    [0.723,0.691],
    [0.982,0.691],
    [0.783,0.691],
    [0.722,0.691,0.126],
    [0.927,0.691],
    [0.851,0.691,0.063],
    [0.655,0.691],
    [0.652,0.691,0.126],
    [0.789,0.691],
    [0.786,0.691],
    [1.24,0.691],
    [0.983,0.691],
    [0.976,0.691],
    // 50 - 5F
    [0.977,0.691,0.189],
    [0.976,0.691,0.0378],
    [0.978,0.691],
    [0.978,0.691],
    [0.79,0.691],
    [0.851,0.691],
    [0.982,0.691],
    [1.24,0.691],
    [0.849,0.691],
    [0.984,0.691,0.189],
    [0.711,0.691,0.126],
    [0.257,0.749,0.25],
    [0,0,0],
    [0.257,0.749,0.25],
    [0.59,0.691],
    [0,0,0],
    // 60 - 6F
    [0,0,0],
    [0.603,0.475],
    [0.59,0.691],
    [0.464,0.475],
    [0.589,0.629],
    [0.472,0.475],
    [0.388,0.691,0.189],
    [0.595,0.475,0.189],
    [0.615,0.691,0.189],
    [0.331,0.691],
    [0.332,0.691],
    [0.464,0.691],
    [0.337,0.691],
    [0.921,0.475],
    [0.654,0.475],
    [0.609,0.475],
    // 70 - 7F
    [0.604,0.527,0.189],
    [0.596,0.475,0.189],
    [0.46,0.475],
    [0.523,0.475],
    [0.393,0.629],
    [0.589,0.475],
    [0.604,0.527],
    [0.918,0.527],
    [0.459,0.475,0.189],
    [0.589,0.475,0.189],
    [0.461,0.475,0.189],
    [0,0,0],
    [0,0,0],
    [0.254,0.691],
    [0,0,0],
    [0.542,0.691]
  ]

});
jsMath.Setup.EncodeFont('eufb10');

jsMath.Font.Register({
  name: 'eufb10',
  prefix: 'jsMath-',
  style: 'font-family: jsMath-eufb10, cursive',
  // The test used to see if font is available
  test: jsMath.Font.Test1, testChar: 0x2D, testFactor: 2,
  // Can add style, styles, macros here
  tex: function (font,fam) {
    // do browser-specific adjustments here
  },
  fallback: function (font,fam) {
    jsMath.Update.TeXfonts({
      eufb10: {
        '0': {c: 'd'},
        '1': {c: 'd'},
        '2': {c: 'f'},
        '3': {c: 'f'},
        '4': {c: 'g'},
        '5': {c: 't'},
        '6': {c: 't'},
        '7': {c: 'u'},
        '18': {c: '&#x2018;'},
        '19': {c: '&#x2019;'},
        '125': {c: '"'},
        '127': {c: '1'}
      }
    });
  }
});
