/*
 *  eusb10/def.js
 *  
 *  This file loads the  font into jsMath. To do this use
 *  
 *      <SCRIPT>jsMath.Font.Load("eusb10")</SCRIPT>
 *
 *  after loading jsMath.js itself.  The user will need to have
 *  the eusb10.ttf font installed, otherwise corresponding unicode
 *  characters will be used, but the mapping is not perfect, and it is not 
 *  customized on a per-browser basis as it probably should be.
 *  
 *  If the font isn't installed, the user will receive a message indicating
 *  that fact, and pointing to the jsMath web site where the font can be
 *  downloaded.
 *  
 *  Once this file is loaded, you can use \char{eusb10}{nn} to access
 *  any character in the font.  In addition, the \eusb10 macro will switch to
 *  the eufm font
 *  
 *  ---------------------------------------------------------------------
 *
 *  jsMath is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  jsMath is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with jsMath; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

jsMath.Add(jsMath.TeX,{

  eusb10: [
    // 00 - 0F
    [0.854,0.583,0.0832],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    // 10 - 1F
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0.623,0.486],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    // 20 - 2F
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    // 30 - 3F
    [0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0.773,0.486],
    [0,0,0],
    [0.936,0.702],
    [0.627,0.702],
    [0,0,0],
    [0,0,0],
    // 40 - 4F
    [0.875,0.702],
    [0.886,0.702,0,{krn: {'48': 0.157}}],
    [0.864,0.702],
    [0.681,0.702],
    [0.938,0.702],
    [0.687,0.702],
    [0.755,0.702],
    [0.683,0.702,0.126],
    [0.999,0.702],
    [0.563,0.702,0,{krn: {'48': 0.0627}}],
    [0.572,0.702,0.126,{krn: {'48': 0.0627}}],
    [0.93,0.702],
    [0.808,0.702],
    [1.11,0.702],
    [0.875,0.702],
    [0.8,0.702],
    // 50 - 5F
    [0.746,0.702],
    [0.765,0.702],
    [0.817,0.702],
    [0.599,0.702],
    [0.654,0.702,0,{ic: 0.061}],
    [0.799,0.702],
    [0.751,0.702],
    [1.12,0.702],
    [0.81,0.702],
    [0.681,0.702],
    [0.742,0.702],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0.876,0.702],
    [0.876,0.702],
    // 60 - 6F
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0.362,0.749,0.25],
    [0.362,0.749,0.25],
    [0,0,0],
    [0,0,0],
    [0.241,0.749,0.25],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0.567,0.749,0.25],
    [0,0,0],
    // 70 - 7F
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0.582,0.189],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0]
  ]

});
jsMath.Setup.EncodeFont('eusb10');

jsMath.Font.Register({
  name: 'eusb10',
  prefix: 'jsMath-',
  // The test used to see if font is available
  test: jsMath.Font.Test1, testChar: 0x3A, testFactor: 2,
  // Can add style, styles, macros here
  tex: function (font,fam) {
    // do browser-specific adjustments here
  },
  fallback: function (font,fam) {
    jsMath.Setup.Styles({
      '.typeset .eusb10': jsMath.styles['.typeset .cmsy10']+', cursive;'
    });
    jsMath.Update.TeXfonts({
      eusb10: {
          '0': {c: '&#x2212;', tclass: 'normal'}, // minus
         '24': {c: '&#x223C;', tclass: 'normal'}, // similar
         '48': {c: ' ', tclass: 'normal'},        // ghost
         '58': {c: '&#xAC;', tclass: 'normal'},   // logicalnot
         '60': {c: '&#x211C;', tclass: 'normal'}, // Rfractur
         '61': {c: '&#x2111;', tclass: 'normal'}, // Ifractur
         '64': {c: '&#x2135;', tclass: 'normal'}, // aleph
         '94': {c: '&#x2227;', tclass: 'normal'}, // logicaland
         '95': {c: '&#x2228;', tclass: 'normal'}, // logicalor
        '102': {c: '&#x7B;', tclass: 'normal'},   // braceleft
        '103': {c: '&#x7D;', tclass: 'normal'},   // braceright
        '106': {c: '&#x7C;', tclass: 'normal'},   // bar
        '110': {c: '&#x5C;', tclass: 'normal'},   // backslash
        '120': {c: '&#xA7;', tclass: 'normal'}    // section
      }
    });
  }
});
