/*
 *  wasyb10/def.js
 *  
 *  This file loads the  font into jsMath. To do this use
 *  
 *      <SCRIPT>jsMath.Font.Load("wasyb10")</SCRIPT>
 *
 *  after loading jsMath.js itself.  The user will need to have
 *  the wasyb10.ttf font installed, otherwise corresponding unicode
 *  characters will be used, but the mapping is not perfect, and it is not 
 *  customized on a per-browser basis as it probably should be.
 *  
 *  If the font isn't installed, the user will receive a message indicating
 *  that fact, and pointing to the jsMath web site where the font can be
 *  downloaded.
 *  
 *  Once this file is loaded, you can use \char{wasyb10}{nn} to access
 *  any character in the font.  In addition, the \wasyb10 macro will switch to
 *  the eufm font
 *  
 *  ---------------------------------------------------------------------
 *
 *  jsMath is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  jsMath is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with jsMath; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

jsMath.Add(jsMath.TeX,{

  wasyb10: [
    // 00 - 0F
    [0.767,0.688],
    [0.894,0.546,0.0523],
    [0.894,0.64,0.148],
    [0.894,0.546,0.0523],
    [0.894,0.64,0.148],
    [0.767,0.431],
    [0.753,0.546],
    [1.04,0.688],
    [0.753,0.688],
    [0.575,0.64],
    [0.489,0.474,0,{ic: 0.0319}],
    [0.639,0.688],
    [0.383,0.688],
    [0.383,0.688],
    [0.447,0.224,0.0347],
    [0.831,0.688],
    // 10 - 1F
    [0.894,0.546,0.0523],
    [0.894,0.546,0.0523],
    [0.511,0.688,0.0993],
    [0.958,0.658,0.148],
    [0.958,0.658,0.148],
    [0.798,0.583,0.0858],
    [0.894,0.64,0.133],
    [0.822,0.688],
    [0.767,0.431],
    [0.558,0.546,0.196],
    [0.813,0.701],
    [0.753,0.546],
    [0.822,0.658],
    [0.894,0.431],
    [0.894,0.64,0.148],
    [0.798,0.583,0.0858],
    // 20 - 2F
    [0.894,0.64,0.133],
    [1.15,0.688,0.196],
    [1.15,0.688,0.196],
    [0.894,0.64,0.133],
    [0.894,0.64,0.133],
    [0.894,0.64,0.133],
    [0.558,0.732],
    [0.558,0.751,0.196],
    [0.383,0.377,-0.123],
    [0.383,0.377,-0.123],
    [0.575,0.688,0.196],
    [0.575,0.688,0.196],
    [0.822,0.658],
    [0.822,0.658],
    [0.822,0.688],
    [0.822,0.658],
    // 30 - 3F
    [0.831,0.688],
    [0.831,0.474,-0.0264],
    [0.781,0.517,0.015],
    [0.808,0.583,0.0858],
    [0.781,0.517,0.015],
    [0.781,0.517,0.015],
    [0.781,0.517,0.015],
    [0.735,0.517,0.015],
    [1.15,0.688,0.196],
    [0.653,0.546,0.0523],
    [0.767,0.377,-0.123],
    [1.15,0.377,-0.123],
    [0.894,0.546,0.0523],
    [0.894,0.546,0.0523],
    [0.894,0.658,0.165],
    [0.894,0.658,0.165],
    // 40 - 4F
    [0.894,0.517,0.015],
    [0.79,0.546,0.0347],
    [0.703,0.583,0.0858],
    [0.703,0.583,0.0858],
    [0.894,0.64,0.133],
    [0.894,0.64,0.133],
    [0.767,0.688],
    [0.894,0.64,0.133],
    [0.894,0.64,0.133],
    [0.894,0.64,0.133],
    [0.894,0.64,0.133],
    [0.598,0.609,0.0993],
    [0.598,0.609,0.0993],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    // 50 - 5F
    [0.383,0.546,0.0523],
    [0.383,0.546,0.0523],
    [0.383,0.546,0.0523],
    [0,0,0],
    [0,0,0],
    [0.526,0.431],
    [0.813,0.701],
    [0.989,0.85,0.0993],
    [0.734,0.688],
    [0.671,0.688,0.196],
    [0.558,0.609,0.116],
    [0.686,0.688,0.181],
    [0.671,0.688],
    [0.822,0.688],
    [0.822,0.688],
    [1.03,0.688],
    // 60 - 6F
    [1.17,0.688,0.196],
    [1.17,0.517],
    [1.17,0.688,0.196],
    [0.705,0.701],
    [0.822,0.688],
    [1.17,0.431],
    [0.822,0.688],
    [0.575,0.688,0.196],
    [1.15,0.751,0.0523],
    [0.639,0.688,0.196],
    [0.786,0.688],
    [0.575,0.688],
    [0.543,0.431],
    [0.55,0.751],
    [0.894,0.701,0.196],
    [0.894,0.701,0.196],
    // 70 - 7F
    [0.894,0.701,0.196],
    [0.894,0.701,0.196],
    [0.479,0,1.11,{ic: 0.224, n: 119}],
    [0.862,0,1.11,{ic: 0.224, n: 120}],
    [1.25,0,1.11,{ic: 0.224, n: 121}],
    [0.831,0,1.11,{n: 122}],
    [0.862,0,1.11,{ic: 0.224, n: 123}],
    [0.639,0,1.67,{ic: 0.256}],
    [1.21,0,1.67,{ic: 0.256}],
    [1.79,0,1.67,{ic: 0.256}],
    [0.639,0,1.67,{ic: 0.256}],
    [1.21,0,1.67,{ic: 0.256}],
    [0.128,0.688],
    [0.894,0.701,0.196],
    [0.894,0.701,0.196],
    [0.575,0.583]
  ]

});
jsMath.Setup.EncodeFont('wasyb10');

jsMath.Font.Register({
  name: 'wasyb10',
  prefix: 'jsMath-',
  // The test used to see if font is available
  test: jsMath.Font.Test1, testChar: 0x74, testFactor: 2,
  // Can add style, styles, macros here
  tex: function (font,fam) {
    // do browser-specific adjustments here
  },
  fallback: function (font,fam) {
    // set up unicode font here, e.g.
    //    jsMath.Update.TeXfonts({
    //      wasyb10: {
    //         '0': {c: '&#x221B;'},  // use code point U221B for character 0
    //        '10': {c: '&#x210C;'}   // use code point U210C for character 10
    //      }
    //    });
  }
});
