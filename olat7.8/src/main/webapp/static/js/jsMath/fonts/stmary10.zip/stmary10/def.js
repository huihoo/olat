/*
 *  stmary10/def.js
 *  
 *  This file loads the  font into jsMath. To do this use
 *  
 *      <SCRIPT>jsMath.Font.Load("stmary10")</SCRIPT>
 *
 *  after loading jsMath.js itself.  The user will need to have
 *  the stmary10.ttf font installed, otherwise corresponding unicode
 *  characters will be used, but the mapping is not perfect, and it is not 
 *  customized on a per-browser basis as it probably should be.
 *  
 *  If the font isn't installed, the user will receive a message indicating
 *  that fact, and pointing to the jsMath web site where the font can be
 *  downloaded.
 *  
 *  Once this file is loaded, you can use \char{stmary10}{nn} to access
 *  any character in the font.  In addition, the \stmary10 macro will switch to
 *  the eufm font
 *  
 *  ---------------------------------------------------------------------
 *
 *  jsMath is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  jsMath is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with jsMath; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

jsMath.Add(jsMath.TeX,{

  stmary10: [
    // 00 - 0F
    [0.778,0.367,-0.133],
    [0.778,0.367,-0.133],
    [0.5,0.583,0.0833],
    [0.5,0.583,0.0833],
    [0.556,0.583,0.0334],
    [0.556,0.528,0.0833],
    [0.611,0.528,0.0334],
    [0.611,0.528,0.0334],
    [0.667,0.694,0.187],
    [0.667,0.694,0.187],
    [0.778,0.528,0.0334],
    [0.556,0.583,0.0833],
    [0.667,0.75,0.25],
    [0.667,0.75,0.25],
    [0.778,0.583,0.0833],
    [0.778,0.583,0.0833],
    // 10 - 1F
    [0.778,0.583,0.0833],
    [0.778,0.583,0.0833],
    [0.778,0.583,0.0833],
    [0.778,0.583,0.0833],
    [0.778,0.583,0.0833],
    [0.778,0.583,0.0833],
    [0.778,0.583,0.0833],
    [0.778,0.583,0.0833],
    [0.778,0.583,0.0833],
    [0.778,0.583,0.0833],
    [0.778,0.583,0.0833],
    [0.778,0.583,0.0833],
    [0.778,0.583,0.0833],
    [0.778,0.583,0.0833],
    [0.778,0.583,0.0833],
    [0.778,0.583,0.0833],
    // 20 - 2F
    [0.611,0.694,0.187],
    [0.889,0.694],
    [0.556,0.694],
    [0.333,0.562,0.187],
    [0.611,0.694,0.187],
    [0.611,0.694,0.187],
    [0.667,0.694,0.187],
    [0.667,0.694,0.187],
    [0.722,0.75,0.25],
    [0.722,0.75,0.25],
    [0.444,0.75,0.25],
    [0.444,0.75,0.25],
    [1,0.694,0.187],
    [0.778,0.68,0.187],
    [0.667,0.694,0.187],
    [0.667,0.694,0.187],
    // 30 - 3F
    [0.611,0.694,0.187],
    [0.611,0.694,0.187],
    [0.778,0.583,0.0833],
    [0.778,0.583,0.0833],
    [0.778,0.583,0.0833],
    [0.778,0.583,0.0833],
    [0.778,0.583,0.0833],
    [0.778,0.583,0.0833],
    [0.5,0.75,0.25],
    [0.694,0.75,0.25],
    [0.778,0.583,0.0833],
    [0.778,0.583,0.0833],
    [0.778,0.583,0.0833],
    [0.778,0.583,0.0833],
    [0.778,0.583,0.0833],
    [0.778,0.583,0.0833],
    // 40 - 4F
    [0.667,0.556],
    [0.667,0.539,0.0334],
    [0.667,0.539,0.0334],
    [0.667,0.556],
    [0.778,0.539,0.0334],
    [0.778,0.539,0.0334],
    [0.778,0.636,0.136],
    [0.778,0.636,0.136],
    [0.444,0.75,0.25],
    [0.444,0.75,0.25],
    [0.403,0.75,0.25],
    [0.403,0.75,0.25],
    [0.389,0.75,0.25],
    [0.389,0.75,0.25],
    [0.778,0.583,0.0833],
    [0.778,0.583,0.0833],
    // 50 - 5F
    [0.778,0.636,0.136],
    [0.778,0.636,0.136],
    [0.778,0.803,0.303],
    [0.778,0.803,0.303],
    [0.556,0.75,0.25],
    [0.556,0.75,0.25],
    [0.556,0.75,0.25],
    [0.556,0.75,0.25],
    [0,0.367,-0.133],
    [0,0.367,-0.133],
    [0,0.367,-0.133],
    [0,0.367,-0.133],
    [0,0.367,-0.133],
    [1,0.472,-0.0278],
    [1,0.472,-0.0278],
    [1,0.472,-0.0278],
    // 60 - 6F
    [0.833,0,1,{n: 104}],
    [0.833,0,1,{n: 105}],
    [0.833,0,1,{n: 106}],
    [0.833,0,1,{n: 107}],
    [0.833,0,1,{n: 108}],
    [0.833,0,1,{n: 109}],
    [0.444,0,1,{n: 110}],
    [0.611,0,1,{n: 111}],
    [1.11,0.1,1.5],
    [1.11,0.1,1.5],
    [1.11,0.1,1.5],
    [1.11,0.1,1.5],
    [1.11,0.1,1.5],
    [1.11,0.1,1.5],
    [0.556,0.1,1.5],
    [0.833,0.1,1.5],
    // 70 - 7F
    [0.833,0,1,{n: 120}],
    [0.528,0.04,1.16,{n: 114}],
    [0.583,0.04,1.76,{n: 115}],
    [0.639,0.04,2.36,{n: 116}],
    [0.694,0.04,2.96,{n: 117}],
    [0.778,0.04,1.76,{delim: {top: 117, bot: 118, rep: 119}}],
    [0.778,0.04,1.76],
    [0.778,0,0.6],
    [1.11,0.1,1.5],
    [0.528,0.04,1.16,{n: 122}],
    [0.583,0.04,1.76,{n: 123}],
    [0.639,0.04,2.36,{n: 124}],
    [0.694,0.04,2.96,{n: 125}],
    [0.778,0.04,1.76,{delim: {top: 125, bot: 126, rep: 127}}],
    [0.778,0.04,1.76],
    [0.778,0,0.6]
  ]

});
jsMath.Setup.EncodeFont('stmary10');

jsMath.Font.Register({
  name: 'stmary10',
  prefix: 'jsMath-',
  // The test used to see if font is available
  test: jsMath.Font.Test1, testChar: 0x2C, testFactor: 2,
  // Can add style, styles, macros here
  tex: function (font,fam) {
    // do browser-specific adjustments here
  },
  fallback: function (font,fam) {
    // set up unicode font here, e.g.
    //    jsMath.Update.TeXfonts({
    //      stmary10: {
    //         '0': {c: '&#x221B;'},  // use code point U221B for character 0
    //        '10': {c: '&#x210C;'}   // use code point U210C for character 10
    //      }
    //    });
  }
});
