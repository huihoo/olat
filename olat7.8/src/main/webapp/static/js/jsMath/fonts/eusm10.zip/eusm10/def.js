/*
 *  eusm10/def.js
 *  
 *  This file loads the eusm10 font into jsMath. To do this use
 *  
 *      <SCRIPT>jsMath.Font.Load("eusm10")</SCRIPT>
 *
 *  after loading jsMath.js itself.  The user will need to have
 *  the eusm10.ttf font installed, otherwise corresponding unicode
 *  characters will be used, but the mapping is not perfect, and it is not 
 *  customized on a per-browser basis as it probably should be.
 *  
 *  If the font isn't installed, the user will receive a message indicating
 *  that fact, and pointing to the jsMath web site where the font can be
 *  downloaded.
 *  
 *  Once this file is loaded, you can use \char{eusm10}{nn} to access
 *  any character in the font.  In addition, the \eusm10 macro will switch to
 *  the eufm font
 *  
 *  ---------------------------------------------------------------------
 *
 *  jsMath is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  jsMath is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with jsMath; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

jsMath.Add(jsMath.TeX,{

  eusm10: [
    // 00 - 0F
    [0.756,0.583,0.0832],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    // 10 - 1F
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0.552,0.459],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    // 20 - 2F
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    // 30 - 3F
    [0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0.684,0.459],
    [0,0,0],
    [0.828,0.702],
    [0.554,0.702],
    [0,0,0],
    [0,0,0],
    // 40 - 4F
    [0.775,0.702],
    [0.771,0.702,0,{krn: {'48': 0.139}}],
    [0.761,0.702],
    [0.603,0.702],
    [0.83,0.702],
    [0.608,0.702],
    [0.649,0.702,0,{ic: 0.027}],
    [0.604,0.702,0.126],
    [0.885,0.702,0,{ic: 0.0135}],
    [0.431,0.702,0,{krn: {'48': 0.0555}}],
    [0.506,0.702,0.126,{krn: {'48': 0.0555}}],
    [0.823,0.702],
    [0.715,0.702],
    [0.982,0.702],
    [0.774,0.702,0,{ic: 0.0135}],
    [0.708,0.702],
    // 50 - 5F
    [0.661,0.702],
    [0.663,0.702],
    [0.723,0.702],
    [0.542,0.702],
    [0.587,0.702,0,{ic: 0.0405}],
    [0.714,0.702],
    [0.665,0.702],
    [0.989,0.702],
    [0.717,0.702],
    [0.596,0.702],
    [0.657,0.702],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0.775,0.702],
    [0.775,0.702],
    // 60 - 6F
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0.32,0.749,0.25],
    [0.32,0.749,0.25],
    [0,0,0],
    [0,0,0],
    [0.213,0.749,0.25],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0.502,0.749,0.25],
    [0,0,0],
    // 70 - 7F
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0.515,0.189],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0],
    [0,0,0]
  ]

});
jsMath.Setup.EncodeFont('eusm10');

jsMath.Font.Register({
  name: 'eusm10',
  prefix: 'jsMath-',
  // The test used to see if font is available
  test: jsMath.Font.Test1, testChar: 0x3A, testFactor: 1.9,
  macros: {mathcal: ['Macro','{\\eusm  #1}',1]},
  // Can add style, styles, here
  tex: function (font,fam) {
    // do browser-specific adjustments here
  },
  fallback: function (font,fam) {
    jsMath.TeX['eusm10'] = jsMath.TeX['cmsy10'];
    jsMath.Setup.Styles({
      '.typeset .eusm10': jsMath.styles['.typeset .cmsy10']+', cursive'
    });
  }
});
